====================================================================================================

Aurora Interactive - Resource Pack - MC Version 1.14+

for Vanilla Minecraft

https://github.com/AuroraInteractive/AuroraPack

====================================================================================================

NOTE:- This Resource Pack is not compatible with older releases of Minecraft.



-Where do I put the Resource Pack?------------------------------------------------------------------

    Run the Minecraft Launcher, log in and press the Play button.

    On the Minecraft title screen select "Options"

    Select "Resource Packs" (bottom left).

    Then select "Open Resource Pack folder" (also on the bottom left).


Alternately on a Windows based system you can:

    Click on "Windows Start" > Run (or search) and copy/paste the following:

    %appdata%/.minecraft/resourcepacks
    
    Then press Enter/Return


Copy/Move the file "Aurora_Pack.zip" into the ".minecraft/resourcepacks" folder (you don't
need to extract it!).


-How do I select this Resource Pack-----------------------------------------------------------------

    Run the Minecraft Launcher, log in and press the Play button.

    On the Minecraft title screen select "Options"

    Select "Resource Packs" (bottom left).

    Then select "Aurora_Pack v1.1.00". (or whatever the latest version is)


-What happens if I declined the RP------------------------------------------------------------------

    If you declined the RP when joining any server, you must allow Resource Packs again.
    
    On the server select screen, Single Click on "Aurora Gaming" (Or whatever you call our server)
    
    Click "Edit" on the bottom left.
    
    Click "Server Resource Packs:" untill "Enabled" is displayed.
    
    Go back to the server select screen, and join us in the action!


That's all,

Happy Mining!!



====================================================================================================